CREATE PROCEDURE account_getall()
  BEGIN
    SELECT * FROM account;
  END;
