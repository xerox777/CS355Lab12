CREATE PROCEDURE account_delete(IN `_account_id` INT)
  BEGIN
    DELETE FROM account WHERE account_id = _account_id;
  end;
