CREATE PROCEDURE school_info(IN `_school_id` INT)
  BEGIN


  Select * from school  where school.school_id = _school_id;
  SELECT * FROM school s LEFT JOIN address a on a.address_id = s.address_id and school_id = _school_id;

END;
