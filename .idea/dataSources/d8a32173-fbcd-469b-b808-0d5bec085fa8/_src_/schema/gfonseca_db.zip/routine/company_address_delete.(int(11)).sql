CREATE PROCEDURE company_address_delete(IN `_company_id` INT)
  BEGIN
    DELETE FROM company_address WHERE company_id = _company_id;
  END;
