CREATE PROCEDURE insert_product(IN `_computer` VARCHAR(50), IN `_tablet` VARCHAR(50), IN `_phone` VARCHAR(50),
                                IN `_other`    VARCHAR(50), IN `_ecorp_id` INT)
  BEGIN

  INSERT INTO products (computer, tablet, phone, other, ecorp_id) VALUES (_computer, _tablet, _phone, _other, _ecorp_id);

END;
