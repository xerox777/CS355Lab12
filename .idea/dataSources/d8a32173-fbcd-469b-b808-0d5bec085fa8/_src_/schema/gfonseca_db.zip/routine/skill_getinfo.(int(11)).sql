CREATE PROCEDURE skill_getinfo(IN `_skill_id` INT)
  BEGIN
    SELECT * FROM skill WHERE skill_id = _skill_id;
    
  end;
