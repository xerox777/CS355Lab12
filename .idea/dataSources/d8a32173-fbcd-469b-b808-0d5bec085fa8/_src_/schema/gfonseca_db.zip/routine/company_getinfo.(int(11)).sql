CREATE PROCEDURE company_getinfo(IN `_company_id` INT)
  BEGIN

    SELECT * FROM company WHERE company_id = _company_id;

    SELECT a.*, s.company_id FROM address a LEFT JOIN company_address s ON s.address_id = a.address_id
    AND company_id = _company_id;
  END;
