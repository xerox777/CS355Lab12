CREATE PROCEDURE address_getall()
  BEGIN
  SELECT * FROM address;
END;
