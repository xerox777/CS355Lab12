CREATE VIEW EMP AS
  SELECT
    `gfonseca_db`.`employee`.`employee_id` AS `employee_id`,
    `gfonseca_db`.`employee`.`ecorp_id`    AS `ecorp_id`,
    `gfonseca_db`.`employee`.`ssn`         AS `ssn`,
    `gfonseca_db`.`employee`.`fname`       AS `fname`,
    `gfonseca_db`.`employee`.`lname`       AS `lname`,
    `gfonseca_db`.`employee`.`street`      AS `street`,
    `gfonseca_db`.`employee`.`city`        AS `city`,
    `gfonseca_db`.`employee`.`zip`         AS `zip`
  FROM `gfonseca_db`.`employee`;
