CREATE VIEW CUS AS
  SELECT
    `gfonseca_db`.`customer`.`customer_id`         AS `customer_id`,
    `gfonseca_db`.`customer`.`ecorp_id`            AS `ecorp_id`,
    `gfonseca_db`.`customer`.`fname`               AS `fname`,
    `gfonseca_db`.`customer`.`lname`               AS `lname`,
    `gfonseca_db`.`customer`.`address`             AS `address`,
    `gfonseca_db`.`customer`.`city`                AS `city`,
    `gfonseca_db`.`customer`.`state`               AS `state`,
    `gfonseca_db`.`customer`.`zip`                 AS `zip`,
    `gfonseca_db`.`customer`.`subscription_amount` AS `subscription_amount`,
    `gfonseca_db`.`customer`.`description`         AS `description`
  FROM `gfonseca_db`.`customer`;
