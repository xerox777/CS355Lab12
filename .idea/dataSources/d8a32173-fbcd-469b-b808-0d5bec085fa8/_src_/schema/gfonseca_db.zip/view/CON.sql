CREATE VIEW CON AS
  SELECT
    `gfonseca_db`.`consumer_credit`.`consumer_id`  AS `consumer_id`,
    `gfonseca_db`.`consumer_credit`.`fname`        AS `fname`,
    `gfonseca_db`.`consumer_credit`.`lname`        AS `lname`,
    `gfonseca_db`.`consumer_credit`.`credit_score` AS `credit_score`,
    `gfonseca_db`.`consumer_credit`.`amount_owed`  AS `amount_owed`,
    `gfonseca_db`.`consumer_credit`.`ecorp_id`     AS `ecorp_id`
  FROM `gfonseca_db`.`consumer_credit`;
