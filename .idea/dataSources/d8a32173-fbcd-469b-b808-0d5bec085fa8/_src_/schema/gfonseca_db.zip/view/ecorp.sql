CREATE VIEW ecorp AS
  SELECT
    `gfonseca_db`.`Ecorp`.`ecorp_id`     AS `ecorp_id`,
    `gfonseca_db`.`Ecorp`.`partner`      AS `partner`,
    `gfonseca_db`.`Ecorp`.`stock_trends` AS `stock_trends`,
    `gfonseca_db`.`Ecorp`.`street`       AS `street`,
    `gfonseca_db`.`Ecorp`.`zip_code`     AS `zip_code`,
    `gfonseca_db`.`Ecorp`.`city`         AS `city`,
    `gfonseca_db`.`Ecorp`.`state`        AS `state`
  FROM `gfonseca_db`.`Ecorp`;
