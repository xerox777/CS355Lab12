CREATE PROCEDURE skill_getall()
  BEGIN
    SELECT * FROM skill;
  END;
