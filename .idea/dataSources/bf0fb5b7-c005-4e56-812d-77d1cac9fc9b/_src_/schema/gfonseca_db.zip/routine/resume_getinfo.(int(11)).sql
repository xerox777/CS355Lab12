CREATE PROCEDURE resume_getinfo(IN `_resume_id` INT)
  BEGIN
    SELECT * FROM resume WHERE resume_id = _resume_id;
  END;
