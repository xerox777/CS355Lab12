CREATE PROCEDURE school_delete(IN `_address_id` INT)
  BEGIN
      DELETE FROM school WHERE address_id = _address_id;
  END;
