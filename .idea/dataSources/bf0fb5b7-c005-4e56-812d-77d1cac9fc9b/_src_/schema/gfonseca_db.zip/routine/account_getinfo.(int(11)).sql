CREATE PROCEDURE account_getinfo(IN `_account_id` INT)
  BEGIN
    SELECT * FROM account WHERE account_id = _account_id;
  END;
