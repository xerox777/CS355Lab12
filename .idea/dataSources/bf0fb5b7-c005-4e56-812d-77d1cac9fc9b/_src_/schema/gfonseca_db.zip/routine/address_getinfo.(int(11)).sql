CREATE PROCEDURE address_getinfo(IN `_address_id` INT)
  BEGIN
    SELECT * FROM address WHERE address_id = _address_id;
  END;
