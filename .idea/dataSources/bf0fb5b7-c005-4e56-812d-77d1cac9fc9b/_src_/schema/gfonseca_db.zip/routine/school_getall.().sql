CREATE PROCEDURE school_getall()
  BEGIN
    SELECT * FROM school;
  end;
