CREATE VIEW Product AS
  SELECT
    `gfonseca_db`.`products`.`product_id` AS `product_id`,
    `gfonseca_db`.`products`.`computer`   AS `computer`,
    `gfonseca_db`.`products`.`tablet`     AS `tablet`,
    `gfonseca_db`.`products`.`phone`      AS `phone`,
    `gfonseca_db`.`products`.`other`      AS `other`,
    `gfonseca_db`.`products`.`ecorp_id`   AS `ecorp_id`
  FROM `gfonseca_db`.`products`;
